export interface IOlympicData {
    country: string;
    year: number;
    athlete: string;
    sport: string;
    gold: number;
    silver: number;
    bronze: number;
  }